package com.EBillCalc.dao;

public interface QueryMapper {
	public static final String viewAll= "select * from Consumers";

}
