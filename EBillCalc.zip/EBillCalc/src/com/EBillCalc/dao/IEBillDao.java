package com.EBillCalc.dao;

import java.util.List;

import com.EBillCalc.bean.EBillBean;
import com.EBillCalc.exception.EBillException;

public interface IEBillDao {

	public List<EBillBean> viewAllEBillData() throws EBillException;
}
