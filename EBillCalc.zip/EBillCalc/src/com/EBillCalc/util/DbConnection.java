package com.EBillCalc.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.EBillCalc.exception.EBillException;


/**
 * Author 		: CAPGEMINI 
 * Class Name 	: DbConnection
 * Package 		: com.capgemini.donorapplication.utility
 * Date 		: Dec 2, 2017
 */

public class DbConnection {
	public static Connection getConnection() throws EBillException {
		Connection conn = null;

		try {
			InitialContext ic = new InitialContext();
			DataSource ds = (DataSource) ic.lookup("java:/OracleDS");
			conn = ds.getConnection();
		}

		catch (SQLException e) {
			throw new EBillException("SQL Error:"+e.getMessage());
		} catch (NamingException e) {
			throw new EBillException("message from DB/NamingExc:"
					+ e.getMessage());
		}
		return conn;
	}
}
