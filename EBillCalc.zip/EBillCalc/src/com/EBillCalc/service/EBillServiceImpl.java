package com.EBillCalc.service;

import java.util.List;

import com.EBillCalc.bean.EBillBean;
import com.EBillCalc.dao.EBillDaoImpl;
import com.EBillCalc.dao.IEBillDao;
import com.EBillCalc.exception.EBillException;

public class EBillServiceImpl implements IEBillService {

	private IEBillDao eBillDao= new EBillDaoImpl();

	@Override
	public List<EBillBean> viewAllEBillData() throws EBillException {
		return eBillDao.viewAllEBillData();
	}

}
